# mojohelpdesk-chrome-extension by Collective Bias

This is an unoffical extension to bring mojohelpdesk functionallity into GMAIL. It's been completely redone in REACTJS in this version (which I just learned in the last week) and it needs some cleaning up.

Available At https://chrome.google.com/webstore/detail/mojo-helpdesk-extension-b/himdmnjdmgjpoanmgmjiihempplfianj

Still TODO

Gmail
Issue with states and Portlet being Maximized... Currently you can't edit a form in a maximized portlet.

All
Testing